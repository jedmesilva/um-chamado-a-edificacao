// Arquivo principal para iniciar o servidor do projeto
// UM CHAMADO À EDIFICAÇÃO

// Importa o módulo necessário
import './server/index.js';